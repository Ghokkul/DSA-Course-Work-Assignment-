/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maze;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Ghokkul Muhunthan 
 * Student ID: 19079077
 */

//Define a class nanmed FileManager
public class FileManager {
    
    //Declare instance variables
    public String name;            //Stores the name of the file
    public int numberOfLines;      //Stores the number of lines in the file 
    public String[] lineData;      //Stores the lines of data as an array of strings 
    public String data="";         //Stores the entire file's content as a single string 
    
    //Constructor with no arguments
    public FileManager()
    {
        numberOfLines = 0; //Initialize numberOflines to 0
    }        
    
    //Constructor that takes a file name as an argument
    public FileManager(String fileName)
    {
        this.name = fileName;       //Set the name of the file to the rovided fileName
        numberOfLines = 0;          //Initialized numberOfLines to 0 
        File f = new File(name);    //Create a File object with the specified name
        
        try
        {
            //Attempr to read the file using a Scanner 
            Scanner myScanner = new Scanner(f);
            
            //Count the number of lines in the file
            while(myScanner.hasNextLine())
            {
                myScanner.nextLine();
                numberOfLines++;
            }  
            
            myScanner.close(); //Close the scanner when done
        }
        catch(IOException e)
        {
            //Handle any IOException that may occur
            System.out.println("Cannot read the file"+e.getMessage());
        }
        
        //Initialize the lineData array with the number of lines
        lineData = new String[numberOfLines];
    }
    
    //Method to read the content of a file
     public void readFile(String fileName)
    {
        File f;
        if(fileName == null)
            f = new File(this.name);    //Use the stored file name if fileName is null
        else
            f = new File(fileName);    //Use the provided fileName
        try
        {
            //Attempt to read the file using a Scanner
            Scanner myScanner = new Scanner(f);
            int lineNum = 0;
            
            //Read each line in the file
            while(myScanner.hasNextLine())
            {
                String line = myScanner.nextLine();
                //System.out.println(line);
                lineData[lineNum] = line; //Store the line in the lineData array
                data += line; //Append the line to the data String
                lineNum++;
                
            }  
            myScanner.close();  //Close the scanner when done
        }
        catch(IOException e)
        {
            //Handle any IOException that may occur
            System.out.println("Cannot read the file"+e.getMessage());
        }
    }
    
     //Method to write content to a file
    public void writeFile(String fileName, String c)
    {
        File f;
        
        if(fileName == null)
            f = new File(this.name);  //Use the stored file name if fileName is null
        else
            f = new File(fileName);   //Use the provided fileName
        try
        {
            f.createNewFile();  //Create a new file
            FileWriter writer = new FileWriter(f); //Write the provided content to the file
            writer.write(c);
            writer.flush();  //Close the FileWriter when done
            writer.close();  
        }
        catch(IOException e)
        {
            //Handle any IOException that may occur
            System.out.println("Cannot write to the file"+e.getMessage());
        }
    }
}
