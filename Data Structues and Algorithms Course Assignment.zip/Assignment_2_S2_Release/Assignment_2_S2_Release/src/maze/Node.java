/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maze;

/**
 *
 * @author Ghokkul Muhunthan 
 * Student ID: 19079077
 */
public class Node {
   
    //Declare instance variables to store node properties
    public String name;             //Declaring the string variable
    public int x;                   //Variable x
    public int y;                    //Variable y 
    public String leftNodeName;     //LeftNodeName
    public String rightNodeName;    //RightNodeName
    public Node left;               //Reference to the life child node
    public Node right;              //Reference to the right child node 
    public Node previous;           //Reference to the parent node
    
    //Default constructor for Node class
    public Node()
    {
        //Initialize all properties to default values
        this.name = null;
        this.x = 0;
        this.y = 0;
        this.leftNodeName = null;
        this.rightNodeName = null;
        this.left = null;
        this.right = null;
        this.previous = null;
    }
    
    /**
     * @param name    - Name of the Node
     * @param x       - x-coordinate of the Node
     * @param y       - y-coordinate of the Node
     * @param           leftNodeName
     * @param           rightNodeName
     * @param         - Left node name 
     * @param         - Right node name 
     * @param         - previous node 
     */
    public Node(String name, int x, int y, String leftNodeName, String rightNodeName)
    {
        this.name = name;
        this.x = x;
        this.y = y;
        this.leftNodeName = leftNodeName;
        this.rightNodeName = rightNodeName;
        this.left = null;
        this.right = null;
        this.previous = null;
    }
}
