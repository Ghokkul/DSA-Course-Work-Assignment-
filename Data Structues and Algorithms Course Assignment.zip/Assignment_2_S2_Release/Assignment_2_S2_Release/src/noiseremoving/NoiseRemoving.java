/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package noiseremoving;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Ghokkul Muhunthan 
 * Student ID: 19079077
 */
public class NoiseRemoving extends JFrame{

    private String fileName;          //Stores the path of the selected image file
    private JLabel imageLabel;        //Displays the loaded and processed image
    private JPanel buttonPanel;       //Panel for buttons
    private JButton load;             //Button to load an image
    private JButton save;             //Button to save the processed image
    private JButton clean;            //Button to clean the image
    private ImageProcess ip;         //Image processing object
    ImageIcon image;                 //Image displayed in the GUI 
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        NoiseRemoving noiseRemove = new NoiseRemoving(); //Create an instance of the NoiseRemoving class
        
        //Set the default close operation, size, title, visibility, and resizable properties
        noiseRemove.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        noiseRemove.setSize(700,400); //set the size of the frame
        noiseRemove.setTitle("Simple Noise Remover Application"); //Set title for the GUI
        noiseRemove.setVisible(true); //setVisible tre
        noiseRemove.setResizable(false); //setReziable false
    }
    
    //NoiseRemoving GUI Constructor
    public NoiseRemoving ()
    {
        panel(); //Call the panel() method to set up the GUI 
    }
    
    //Generates a GUI panel
    private void panel ()
    {
        //Creates an upload image button
        load = new JButton("Upload image");
        load.addActionListener(new ActionListener() //Actionlistener
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Create a file chooser for image selection 
                JFileChooser imageFileChooser = new JFileChooser(new File("."));
                int stateImageFileChooser = imageFileChooser.showOpenDialog(null);
                
                if(stateImageFileChooser == JFileChooser.APPROVE_OPTION)
                {
                    if(imageLabel != null)
                    {
                        imageLabel.setIcon(null);
                    }
                    //Get the selected image file's path
                    fileName = imageFileChooser.getSelectedFile().getPath();
                    System.out.println(fileName);
                    //Create an ImageIcon from the selected image file
                    image = new ImageIcon(fileName);
                    imageLabel = new JLabel((Icon) image);
                    //Initialize the ImageProcess object with the selected image
                    ip = new ImageProcess(fileName);
                    showImage();                //Display the selected image
                    clean.setEnabled(true);     //Enable the Clean image button
                    save.setEnabled(true);      //Enable the Save image button
                }
            }
        });
        
        //Creates a clean image button
        clean = new JButton("Clean image"); //Button named Clean Image
        clean.setEnabled(false); //Initially disabled
        clean.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                imageLabel.setIcon(null);
                ip.cleanNoise(); //Perform noise removal on the image
                ImageIcon imageIcon = new ImageIcon(ip.buffered_image);
                image = imageIcon;
                showImage(); //Display the cleaned image
                save.setEnabled(true); //Enable the Save Image Button 
            }
        });
        
        //Creates a save image button
        save = new JButton("Save image");
        save.setEnabled(false); //Initially disabled 
        save.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                ip.save("noise_removed.jpg"); //Save the cleaned image
                save.setEnabled(false); //Disable the Save image button after saving 
            }
        });
        
        buttonPanel = new JPanel(); //new jpanel
        buttonPanel.add(load);     //Add Load button
        buttonPanel.add(clean);    //Add clean button
        buttonPanel.add(save);     //Add save button 
        this.add(buttonPanel, BorderLayout.SOUTH); //Add the button panel to the JFrame
    }
    
    //Shows the uploaded image.
    private void showImage()
    {
        //Rezie the image and create a resized ImageIcon 
        ImageIcon resizedImageIcon = new ImageIcon(image.getImage().getScaledInstance(600, 350, java.awt.Image.SCALE_SMOOTH));
        imageLabel.setIcon(resizedImageIcon); 
        this.getContentPane().add(imageLabel, BorderLayout.NORTH);
        this.setVisible(true); //setVisible true
    }
}
