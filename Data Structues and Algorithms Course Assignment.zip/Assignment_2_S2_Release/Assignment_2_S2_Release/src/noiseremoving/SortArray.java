/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package noiseremoving;

/**
 * Question 1:
 *      Is quick sort the best way of finding median? Why?
 * Answer:
 *      In some cases, quick sorting is not the best method for finding the median. 
        There is no guarantee that quick sort will find the median because quick sort is an efficient sorting algorithm. 
        In fact, the worst-case time complexity of quick sort is O(n^2), which could be very slow for finding the median of a large dataset.
         However, in practice, quick sort is often used to find the median because it is a general-purpose algorithm that works well for many types of data.

 * 
 * Question 2:
 *      What is another good way of finding median? Please provide your explanation.
 * Answer:
 *      The selection algorithm is also a good method for finding the median. 
        Unsorted lists are sorted by kth smallest element, using a selection algorithm. 
        We can find the median of an ordered list by selecting the middle element. 
        Over quick sort, the selection algorithm has the advantage of being O(n) in worst-case time complexity. 
        Compared to quick sort, this is much faster. 
        Nevertheless, implementing the selection algorithm may be more challenging than quick sort.

 
 * @author Ghokkul Muhunthan 
 * Student ID: 19079077
 */
public class SortArray <E extends Comparable> {
    
    //Declaring the variable
    public E[] array;
    
    /**
     * Takes a reference of an array and passes the reference to the "array" field.
     * 
     * @param array 
     */
    public void SortArray(E[] array)
    {
        this.array = array;
    }
    
    public void setArray(E[] array)
    {
        this.array = array;
    }
    
    /**
     * Runs quick sort algorithm and sorts array in order using quickSort() recursive method.
     */
    public void quickSort() 
    {
        if (array == null || array.length <= 1) 
        {
            return;
        }
        quickSort(0, array.length - 1);
    }

    /**
     * Recursively performs the quick sort algorithm on the array.
     * 
     * @param low (The lower index of the array)
     * @param high (The higher index of the array)
     */
    private void quickSort(int low, int high) 
    {
        if (low < high) 
        {
            int pivotIndex = partition(low, high);
            quickSort(low, pivotIndex - 1);
            quickSort(pivotIndex + 1, high);
        }
    }

    /**
     * Partitions the array based on a pivot element.
     * 
     * @param low (The lower index of the array)
     * @param high (The higher index of the array)
     * @return The index of the pivot element
     */
    private int partition(int low, int high) 
    {
        E pivot = array[high];
        int i = low - 1;

        for (int j = low; j < high; j++) 
        {
            if (array[j].compareTo(pivot) <= 0) 
            {
                i++;
                swap(i, j);
            }
        }

        swap(i + 1, high);
        return i + 1;
    }

    /**
     * Swaps two elements in the array.
     * 
     * @param i (The index of the first element)
     * @param j (The index of the second element)
     */
    private void swap(int i, int j) 
    {
        E temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}
