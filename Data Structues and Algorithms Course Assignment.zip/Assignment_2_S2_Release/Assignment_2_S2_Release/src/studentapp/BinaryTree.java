/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentapp;

 

/**
 * @author Ghokkul Muhunthan 
 * Student ID:19079077
 */
public class BinaryTree<E, F extends Comparable> {
    //The root node of the binary tree.
    private Node<E, F> root;
    //The total number of nodes in teh binary tree.
    private int number_of_nodes;
    //An array to store nodes in sorted order. 
    private Node[] nodeList;
    //A flage to indicate whether the tree's order is reveresed
    private boolean isTreeReversed;

    /**
     * Constructs a binary tree with a given node as the root.
     *
     * @param node The root node of the binary tree.
     */
    public BinaryTree(Node node) {
        this.root = node;
        this.number_of_nodes = 1;
    }

    /**
     * Constructs a binary tree with a single node that contains the given element and key.
     *
     * @param element The element to be stored in the root node.
     * @param key     The key to be associated with the root node.
     */
    public BinaryTree(E element, F key) {
        this.root = new Node<>(element, key);
        this.number_of_nodes = 1;
    }

    /**
     * Constructs an empty binary tree.
     */
    public BinaryTree() {
        this.root = null;
        this.number_of_nodes = 0;
        this.isTreeReversed = false;
    }

    /**
     * Adds a new node to the binary tree with the given element and key.
     *
     * @param element The element to be stored in the new node.
     * @param key     The key to be associated with the new node.
     */
    public void addElement(E element, F key) {
        Node<E, F> newNode = new Node<>(element, key);
        addNode(root, newNode);
    }

    /**
     * Helper method for adding a node to the binary tree.
     *
     * @param root The root node of the current subtree.
     * @param node The node to be added to the binary tree.
     */
    public void addNode(Node root, Node node) {
        if (this.root == null) {  // If the tree is empty
            this.root = node;  // Set the new node as the root
            number_of_nodes++;  // Increment the number of nodes in the tree
            return;
        }

        // If the key of the new node is less than the key of the current root node
        if (node.getKey().compareTo(root.getKey()) < 0) {
            if (root.getLeft() == null) {  // If the left child of the root is empty
                root.setLeft(node);  // Set the new node as the left child of the root
                number_of_nodes++;  // Increment the number of nodes in the tree
            } else {
                addNode(root.getLeft(), node);  // Recursively call addNode on the left subtree
            }
        }
        // If the key of the new node is greater than the key of the current root node
        else if (node.getKey().compareTo(root.getKey()) > 0) {
            if (root.getRight() == null) {  // If the right child of the root is empty
                root.setRight(node);  // Set the new node as the right child of the root
                number_of_nodes++;  // Increment the number of nodes in the tree
            } else {
                addNode(root.getRight(), node);  // Recursively call addNode on the right subtree
            }
        }
    }

    /**
     * Traverses each node in the current binary tree and displays node elements' details in the order of
     * from smallest key value to the largest key value, or from the largest key value to the smallest key value
     * depending on whether reverseOrder() has been called.
     *
     * @param root The root node of the current subtree to start the traversal from.
     */
    public void traversal(Node root) {
        if (root != null) {
            if (isTreeReversed()) {
                traversal(root.getRight());  // Recursively traverse the right subtree first
                System.out.println(root.getElement().toString());
                traversal(root.getLeft());  // Recursively traverse the left subtree afterwards
            } else {
                traversal(root.getLeft());  // Recursively traverse the left subtree first
                System.out.println(root.getElement().toString());
                traversal(root.getRight());  // Recursively traverse the right subtree afterwards
            }
        }
    }

    /**
     * Returns an array of the nodes in the binary tree in sorted order (inorder traversal).
     *
     * @return An array of nodes in the binary tree in sorted order.
     */
    public Node[] toSortedList() {
        nodeList = new Node[number_of_nodes];
        number_of_nodes = 0; // Reset counter
        toSortedListHelper(this.root);
        return nodeList;
    }

    /**
     * Helper method for converting the binary tree to a sorted array of nodes.
     *
     * @param root The root node of the current subtree.
     */
    private void toSortedListHelper(Node root) {
        if (root != null) {
            toSortedListHelper(root.getLeft());
            nodeList[number_of_nodes] = root;
            number_of_nodes++;
            toSortedListHelper(root.getRight());
        }
    }

    /**
     * Searches the binary tree for a node with the given key and returns the corresponding element.
     *
     * @param key The key to search for in the binary tree.
     * @return The element associated with the node with the given key, or null if the key is not found.
     */
    public E searchElement(F key) {
        if (key == null) {
            return null;
        }
        Node<E, F> targetNode = new Node<>(null, key); // Create a target node with the specified key
        Node<E, F> resultNode = searchNode(root, targetNode); // Call searchNode to find the node with the key
        return resultNode != null ? resultNode.getElement() : null; // Return the element of the resultNode if it is found otherwise null
    }

    /**
     * This method helps to search for a specific node in the binary tree by recursively traversing
     * the tree and comparing the keys until a match is found or the end of the tree is reached.
     *
     * @param root The root node of the current subtree to start the search from.
     * @param node The node to search for in the binary tree.
     * @return The node with the given key, or null if the key is not found.
     */
    public Node searchNode(Node root, Node node) {
        if (root == null || node == null) {  // If the tree is empty or the node is null
            return null;
        }

        int cmp;
        if (isTreeReversed()) {  // If reversed search is enabled
            cmp = node.getKey().compareTo(root.getKey());  // Compare the key of the given node with the root's key
        } else {
            cmp = root.getKey().compareTo(node.getKey());  // Compare the key of the root with the given node's key
        }

        if (cmp == 0) {  // If the keys are equal, the node is found
            return root;
        } else if (cmp > 0) {  // If the root's key is greater than the given node's key
            return searchNode(root.getLeft(), node, isTreeReversed());  // Recursively search in the left subtree
        } else {  // If the root's key is less than the given node's key
            return searchNode(root.getRight(), node, isTreeReversed());  // Recursively search in the right subtree
        }
    }

    /**
     * Helper method for searching the binary tree for a node with the given key.
     *
     * @param root The root node of the current subtree.
     * @param node The node to search for in the binary tree.
     * @return The node with the given key, or null if the key is not found.
     */
    public Node searchNode(Node root, Node node, boolean isReversed) {
        if (root == null || node == null) {  // If the tree is empty or the node is null
            return null;
        }

        int cmp;
        if (isReversed) {  // If reversed search is enabled
            cmp = node.getKey().compareTo(root.getKey());  // Compare the key of the given node with the root's key
        } else {
            cmp = root.getKey().compareTo(node.getKey());  // Compare the key of the root with the given node's key
        }

        if (cmp == 0) {  // If the keys are equal, the node is found
            return root;
        } else if (cmp > 0) {  // If the root's key is greater than the given node's key
            return searchNode(root.getLeft(), node, isReversed);  // Recursively search in the left subtree
        } else {  // If the root's key is less than the given node's key
            return searchNode(root.getRight(), node, isReversed);  // Recursively search in the right subtree
        }
    }

    /**
     * This method reverses the order of the binary tree by swapping the left and right child nodes of each node,
     * starting from the root and recursively calling itself on each child node until the end of the tree is reached.
     * Note that this method does not return anything, but modifies the tree in place.
     */
    public void reverseOrder() {
        reverseOrder(this.root);
    }

    /**
     * This is a private helper method used by the public reverseOrder method to recursively reverse the order of the
     * binary tree by swapping the left and right child nodes of each node, starting from the current node and recursively
     * calling itself on each child node until the end of the tree is reached.
     * Note that this method does not return anything, but modifies the tree in place.
     *
     * <br>
     * <br>
     * Solution for O(n) time complexity
     * <p>
     * In the method, each node is visited exactly once, and for each node, a constant time operation is performed, which includes swapping the left and right child nodes and recursively reversing the left and right subtrees. This operation takes a constant amount of time regardless of the size of the tree.
     * Since each node is visited once, the time complexity of the reverseOrder method is linear with respect to the number of nodes in the tree. Therefore, it has a time complexity of O(n).
     *
     * @param node The node to start the recursive reversal from.
     */
    private void reverseOrder(Node node) {
        if (node == null) {    // If the current node is null, return
            return;
        }

        // swap the left and right child nodes of the current node
        Node<E, F> temp = node.getLeft();
        node.setLeft(node.getRight());
        node.setRight(temp);

        // recursively reverse the left and right subtrees
        reverseOrder(node.getLeft());  // Reverse the left subtree
        reverseOrder(node.getRight());  // Reverse the right subtree
    }

    /**
     * This method returns the current status of the isTreeReversed flag.
     *
     * @return A boolean indicating whether the order of the binary trees storing the students is reversed or not.
     */
    public boolean isTreeReversed() {
        return isTreeReversed;
    }

    /**
     * This method sets the value of the isTreeReversed flag to the given boolean value.
     *
     * @param treeReversed A boolean value indicating whether the order of the binary trees storing the student should be reversed or not.
     */
    public void setTreeReversed(boolean treeReversed) {
        isTreeReversed = treeReversed;
    }
}


  /*
      private void reverseOrder(Node root)
    {

    }
    */