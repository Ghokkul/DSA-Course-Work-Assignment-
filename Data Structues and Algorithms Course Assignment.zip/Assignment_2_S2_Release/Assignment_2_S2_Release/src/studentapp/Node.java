 
package studentapp;

/**
 * @author Ghokkul Muhunthan 
 * Student ID: 19079077
 */

public class Node<E, F extends Comparable> implements Comparable<Node> {
    // The element stored in the node
    private E element;

    // The key used for comparison
    private F key;

    // Reference to the left child node
    private Node<E, F> l_node;

    // Reference to the right child node
    private Node<E, F> r_node;


    /**
     * Constructs a new Node with null element and key.
     */
    public Node() {
        this(null, null);
    }

    /**
     * Constructs a new Node with the given element and null key.
     *
     * @param element The element to be stored in the node.
     */
    public Node(E element) {
        this(element, null);
    }

    /**
     * Constructs a new Node with the given element and key.
     *
     * @param element The element to be stored in the node.
     * @param key     The key used for comparison.
     */
    public Node(E element, F key) {
        this.element = element;
        this.key = key;
        this.l_node = null;
        this.r_node = null;
    }

    /**
     * Returns the element stored in the node.
     *
     * @return The element stored in the node.
     */
    public E getElement() {
        return element;
    }

    /**
     * Sets the element stored in the node.
     *
     * @param element The element to be stored in the node.
     */
    public void setElement(E element) {
        this.element = element;
    }

    /**
     * Returns the key used for comparison.
     *
     * @return The key used for comparison.
     */
    public F getKey() {
        return key;
    }

    /**
     * Sets the key used for comparison.
     *
     * @param key The key used for comparison.
     */
    public void setKey(F key) {
        this.key = key;
    }

    /**
     * Returns the left child node.
     *
     * @return The left child node.
     */
    public Node<E, F> getLeft() {
        return l_node;
    }

    /**
     * Sets the left child node.
     *
     * @param left The left child node.
     */
    public void setLeft(Node<E, F> left) {
        this.l_node = left;
    }

    /**
     * Returns the right child node.
     *
     * @return The right child node.
     */
    public Node<E, F> getRight() {
        return r_node;
    }

    /**
     * Sets the right child node.
     *
     * @param right The right child node.
     */
    public void setRight(Node<E, F> right) {
        this.r_node = right;
    }

    @Override
    public int compareTo(Node node) {
        return this.key.compareTo(node.key);
    }
}
