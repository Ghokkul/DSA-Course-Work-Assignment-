 
package studentapp;


/**
 * @author Ghokkul Muhunthan 
 * Student ID:19079077
 */
public class Student {
    
    //Declare instance variables
    public String name;       //Name of the student
    public Float score;      //Score of the student
    public String comments;  //Comments about the student

    //Constructor to initialize the student object
    Student(float score, String name, String comments) 
    {
       this.score = score;           //Set the score
       this.name = name;             //Set the name
       this.comments = comments;     //Set the comments
    }
 
    //Override the toString() method to provide a custom string representation of the object. 
    public String toString()
    {
        return name +"\n" + score +"\n" + comments;
    }
}
