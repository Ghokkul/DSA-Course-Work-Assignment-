package studentapp;

/**
 * @author Ghokkul Muhunthan 
 * Student ID:19079077
 */
public class StudentManager<F  extends Comparable> {
    
     private BinaryTree<Student, Score> bTreeDate;
    private BinaryTree<Student, String> bTreeTitle;
    
     /**
     * Adds a Student object to the StudentManager with the given score, name, and comments.
     *
     * @param score    The score of the student.
     * @param name     The name of the student.
     * @param comments The comments from the student.
     */
    public void addStudent(float score, String name, String comments)
    {
        Student student = new Student((score), name, comments);
        student.comments=comments;
        student.name=name;
        student.score=score;
       //test code
       addToTree(student, (F) (name));
      // addToTree(student, (F) (score));
      }
    
     /**
     * Helper method that adds a student object to the appropriate Binary Tree with the given key.
     *
     * @param student student object to add.
     * @param key  The key of either Float or String type.
     */
    public void addToTree(Student student, F key)
    {
        if (key instanceof Student) {
            if (bTreeDate == null) {
                bTreeDate = new BinaryTree();
            }
            bTreeDate.addElement(student, (Score) key);
        } else if (key instanceof String) {
            if (bTreeTitle == null) {
                bTreeTitle = new BinaryTree();
            }
            bTreeTitle.addElement(student, (String) key);
        }
    }
    
    /**
     * Searches the appropriate Binary Tree for a Student object with the given key.
     *
     * @param key The key of either Score or String type.
     * @return The Student object with the given key, or null if the key is not found.
     */
    public Student findStudent(F key)
    {
        F targetScoreKey = key;
        Student targetScore; 
 
        if(targetScoreKey instanceof Score)
        {
          targetScore = (Student) bTreeDate.searchElement((Score) targetScoreKey);
          return targetScore;
        } else if (targetScoreKey instanceof String)
        {
          targetScore = (Student) bTreeTitle.searchElement((String) targetScoreKey);
          return targetScore;
        }
         
        /*  
         if (key != null) {
            if (key instanceof Score) {
                return bTreeDate.searchElement((Score) key);
            } else if (key instanceof String) {
                return bTreeTitle.searchElement((String) key);
            }
        }
             return null;    
        */
         return null;
    }
    
     /**
     * Gets a sorted list of Student objects from the appropriate Binary Tree with the given key.
     *
     * @param key The key of either Float or String type.
     * @return A sorted array of Student objects with the given key, or null if the key is not of the correct type.
     */
    public Student[] getSortedStudentList(F key)
    {
        if (key instanceof Float) {
            Node<Student, Score>[] nodeList = bTreeTitle.toSortedList();
            Student[] StudentList = new Student[nodeList.length];
            for (int i = 0; i < nodeList.length; i++) {
                StudentList[i] = nodeList[i].getElement();
            }
            return StudentList;
        } else if (key instanceof String) {
            Node<Student, String>[] nodeList = bTreeTitle.toSortedList();
            Student[] stuList = new Student[nodeList.length];
            for (int i = 0; i < nodeList.length; i++) {
                stuList[i] = nodeList[i].getElement();
            }
            return stuList;
        }
        return null;    
    }
    
     /**
     * This method reverses the order of the binary trees storing the student by score and title,
     * effectively reversing the order in which the elements were added to the trees.
     * It calls the reverseOrder() method on both binary trees and sets the isTreeReversed flag of the tree to true.
     */
    public void reverseOrder()
    {
        bTreeDate.reverseOrder();
        bTreeDate.setTreeReversed(true);
        bTreeTitle.reverseOrder();
        bTreeTitle.setTreeReversed(true);
    }

    private void addToTree(Student student, float score) {
     }

    private static class Score implements Comparable {

        public Score() {
        }

        @Override
        public int compareTo(Object o) {
            return 0;
         }
    }
    
} 